A Pen created at CodePen.io. You can find this one at https://codepen.io/jerriais/pen/mjBbJy.

 Gooey menu with CSS and SVG filters. Version 1